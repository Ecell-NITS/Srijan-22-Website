const getIndexPage = (req, res) => {
    res.render('index');
}

module.exports = {
    getIndexPage,
}